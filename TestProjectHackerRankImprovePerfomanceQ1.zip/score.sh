echo "This custom script can run any bash command, and perform tests."
echo "It needs to only output on1 line in the format 'FS_SCORE:xx%', where xx is the percentage score for the solution."
echo "FS_SCORE:70%" 

FS_SCORE:70%
